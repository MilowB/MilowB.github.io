# Nom : Le meilleur partenaire
# Paramètre : liste de tuples <nom, force, taille>
# Retour : string - le nom du héro qui a le score force * taille le plus petit
def exercice1(input):
    #TODO
    return ""

# Nom : Contacter le nouveau partenaire
# Paramètre : string - nom du héro à contacter, dictionnaire - le répertoire téléphonique de Batman
# Retour : string - le numéro de la personne que Batman a choisi
def exercice2(name, input):
    #TODO
    return ""

# Nom : Une menace pèse
# Paramètre : set - lieux que le Joker veut attaquer, set - lieux impossibles à surveiller par la police
# Retour : set - lieux que Batman et son acolyte doivent surveiller
def exercice3(set1, set2):
    #TODO
    return set()

# Nom : Organisation des rondes
# Paramètre : set - lieux que Batman et son partenaire doivent surveiller
# Retour : set - lieux que Batman doit surveiller
def exercice4(input):
    #TODO
    return set()