from exemple import *
from rescale import *
import math
import random

def ex1_data_generation():
    data = []
    name = "hero"
    for i in range(random.randint(20, 100)):
        fullname = name + str(i)
        strength = random.randint(1, 100)
        size = random.randint(100, 200)
        data.append((fullname, strength, size))
    return data
    
def ex2_data_generation():
    data = {}
    name = "hero"
    ret_name = ""
    nb_data = random.randint(20, 100)
    for i in range(nb_data):
        fullname = name + str(i)
        number = "06"
        for i in range(8):
            number += str(random.randint(0, 9))
        data[fullname] = number
    j = random.randint(0, len(data) - 1)
    cnt = 0
    for key in data:
        if cnt == j:
            ret_name = key
        cnt += 1
    return ret_name, data

def ex3_data_generation():
    joker_places = set()
    not_police_places = set()
    place_name = "place"
    nb_data = random.randint(10, 110)
    for i in range(nb_data):
        fullname = place_name + str(i)
        joker_places.add(fullname)
        if random.randint(0, 3) <= 0 :
            not_police_places.add(fullname)
    return joker_places, not_police_places

def ex4_data_generation():
    places = set()
    place_name = "place"
    nb_data = random.randint(10, 110)
    for i in range(nb_data):
        fullname = place_name + str(i)
        places.add((fullname, random.randint(25, 5000)))
    return places
