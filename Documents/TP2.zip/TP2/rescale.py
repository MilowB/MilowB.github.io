def rescale(max_out, max_in, value):
    return value * max_out / max_in