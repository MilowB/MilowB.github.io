# Paramètre : string, les données détaillées dans le sujet du TP
# Retour : set - les noms des suspects qui ont pu poser la bombe
def exercice1(input):
    #TODO
    return set()