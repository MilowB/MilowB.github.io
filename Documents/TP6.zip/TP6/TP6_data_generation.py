from exemple import *
import math
import random
import string

def ex21_data_generation():
    r = random.randint(99, 500)
    res = ""
    for i in range(r):
        c = random.randint(5, 99)
        res += ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(c))
        res += " "
    return res

def ex22_data_generation():
    base_url = "https://www.seloger.com/"
    prix_max = random.randint(100000, 999999)
    prix_min = random.randint(0, 99999)
    res = []
    for i in range(random.randint(50, 100)):
        res.append(base_url + "list.htm?projects=2,5&types=1,2&natures=1,2,4&places=[{%22inseeCodes%22:[690383]}]&price=" + str(prix_min) + "/" + str(prix_max) + "&enterprise=0&qsVersion=1.0&m=search_hp_last")
    return res
    
def ex23_data_generation():
    base_url = "https://www.seloger.com/"
    prix_max = random.randint(100000, 999999)
    prix_min = random.randint(0, 99999)
    surface_min = random.randint(100, 150)
    surface_max = random.randint(50, 100)
    types = random.randint(0, 4)
    res = []
    for i in range(random.randint(50, 100)):
        res.append(base_url + "list.htm?projects=2,5&types=" + str(types) + "&natures=1,2,4&places=[{%22inseeCodes%22:[690383]}]&price=" + str(prix_min) + "/" + str(prix_max) + "&surface=" + str(surface_min) + "/" + str(surface_max) + "&enterprise=0&qsVersion=1.0&m=search_hp_last")
    return res

def ex3_data_generation():
    max = 12
    res = ""
    for i in range(max):
        c = random.randint(0, 9)
        res += str(c)
    return res

def ex4_data_generation():
    nbMots = 3
    res = []
    for i in range(nbMots):
        c = random.randint(6, 21)
        res.append(''.join(random.choice(string.ascii_uppercase) for _ in range(c)))
    return res
