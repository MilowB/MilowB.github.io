from parse import *
from TP6_data_generation import *

# Nom : Les chaînes de caractères (mots de passe)
# Paramètre : string (la chaîne de mots de passe)
# Retour : une liste de string (les mots de passe dans une liste)
def exercice21(input):
    #TODO
    return ""

# Nom : Les chaînes de caractères (recherche du prix max)
# Paramètre : une liste de string (les uri)
# Retour : une liste de int (les prix max dans chaque uri)
def exercice22(input):
    #TODO
    return ""

# Nom : Les chaînes de caractères (récupération de données multiples)
# Paramètre : une liste de string (les uri)
# Retour : le résultat de la fonction parse() du module Parse
def exercice23(input):
    #TODO
    return ""


# Nom : Les nombres
# Paramètre : une chaine de 12 caractères
# Retour : une liste d'entiers
def exercice3(input):
    #TODO
    return []

# Nom : Modification de données
# Paramètre : une liste de 3 strings
# Retour : le second mot écrit en alternant majuscule et minuscule
def exercice4(input):
    #TODO
    return ""

# Génération aléatoire de données pour les exercices pour vous vérifier vos algo
if __name__ == "__main__":
    exercice21(ex21_data_generation())
    exercice22(ex22_data_generation())
    exercice23(ex23_data_generation())
    exercice3(ex3_data_generation())
    exercice4(ex4_data_generation())
