# Paramètre : age de la personne
# Retour : True si age >= 20, False sinon
def exercice1(age):
    #TODO
    return True

def exercice2():
    #TODO
    pass

# Bonus
# Paramètre : indice du terme la suite de Fibonacci souhaité
# Retour : valeur du nème terme
def exercice3(indice):
    #TODO 
    return 1