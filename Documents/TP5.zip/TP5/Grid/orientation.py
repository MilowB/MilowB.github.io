from enum import Enum

class Orientation(Enum):
    EST = 0
    NORTH = 1
    WEST = 2
    SOUTH = 3