# EnvironmentGrid
A simple environment. A turtle can move into a grid.

Graphism are made with PyGame


# How to use ?

Install pygame :

> python3 -m pip install -U pygame --user

OR if not working :

> python3 -m pip install pygame==2.0.0.dev6

Then :

> python main.py
