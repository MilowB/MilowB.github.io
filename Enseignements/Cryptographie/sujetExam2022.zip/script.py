'''
-------------------------------
# CONSIGNES
-------------------------------

/!\ Cette évaluation sera corrigée automatiquement /!\ 

/!\ Si les instructions suivantes ne sont pas respectées, l'algorithme ne fonctionnera pas et 
vous serez fortement susceptible d'avoir 0 /!\ 

1) Remplissez votre prénom et votre nom dans les variables __PRENOM__ et __NOM__ dans 
la fonction identifiants()

2) Remplissez les méthodes précédées de la mention #TODO (...)

3) Ne touchez pas aux en-têtes des fonctions (ne pas modifier les paramètres)

4) Respectez les formats de sortie des fonctions (les valeurs retournées). Des exemples sont
donnés pour vous aider à comprendre ce qui est attendu en sortie.

5) Vous devrez utiliser le package AES utilisé durant le TP1 (commande d'installation si besoin: pip install aes-cipher). 
Vous avez le droit de vous aider du web et des cours, mais pas du package RSA du TP2.

Il est également interdit de communiquer avec les autres étudiants.


** Comment tester votre script ? **

Vous pouvez tester vos fonction manuellement en les appelant en bas de page par vous même et 
vérifier leur sortie.

Vous pouvez aussi exécuter le code fourni dans main.py et vérifier que tout fonctionne bien 
(et simuler votre future note accessoirement). Ce script sera utilisé pour la correction 
automatisée.

** Attention **

Toute tentative de communication avec un autre étudiant via internet sera passible d'une convocation auprès de la commission académique de discipline.

-------------------------------
# TRAVAIL A REALISER
-------------------------------

Dans cet exercice vous devrez remplir les fonctions permettant de:
1) chiffrer un message avec AES
2) déchiffrer un message avec AES
3) chiffrer un messages avec RSA
4) déchiffrer un message avec RSA

'''

import random
from aes_cipher import (
    DataDecrypter, DataEncrypter, Pbkdf2Sha512Default
)

#TODO
# Remplissez ces variables pour y affecter votre future note
def identifiants():
    __PRENOM__ = "prénom"
    __NOM__ = "nom"
    return __PRENOM__, __NOM__


###############################################################################################
################################       AES  7 points     ######################################
###############################################################################################

def generer_clef():
    return "votre_clef"

def generer_chiffreurf():
    return DataEncrypter(Pbkdf2Sha512Default)

def generer_dechiffreurf():
    return DataDecrypter(Pbkdf2Sha512Default)
    
#TODO
# Objectif: cette fonction chiffre des données avec AES
# Paramètres: chiffreur, l'objet DataEncrypter du package AES mentionné dans le (5) des consignes;
# clef, la clef utilisée pour chiffrer le message; donnees, les données à chiffer
# Sortie: le message chiffré avec la clef et le chiffreur
def chiffrer_message_aes(chiffreur, clef, donnees):
    pass

#TODO
# Objectif: cette fonction déchiffre des données avec AES
# Paramètres: chiffreur, l'objet DataDecrypter du package AES mentionné dans le (5) des consignes;
# clef, la clef utilisée pour chiffrer le message; donnees, les données à chiffer
# Sortie: le message déchiffré avec la clef et le déchiffreur
def dechiffrer_message_aes(dechiffreur, clef, donnees):
    pass

###############################################################################################
################################      RSA   13 points    ######################################
###############################################################################################


#TODO
# Objectif: cette fonction calcule le pgcd de a et b
# Paramètres: a et b, les valeurs dont il faut calculer le pgcd
# Sortie: le plus grand dénominateur commun entre a et b
def pgcd(a, b):
    pass

#TODO
# Objectif: cette fonction recherche un nombre premier compris dans un intervalle
# Paramètres: borne_min, la borne basse de l'intervalle; borne_max, la borne haute de l'intervalle
# Sortie: une valeur qui est un nombre premier (ex: 3, 7, 11, etc.)
def generer_nombre_premier(borne_min, borne_max):
    pass

#TODO
# Objectif: cette fonction calcule e, la clef publique de RSA
# Paramètres: phi, le paramètre généré pour RSA
# Sortie: la clef publique e pour RSA
def generer_e_rsa(phi):
    pass

# Objectif: cette fonction calcule l'inverse d'un nombre a sur son ensemble Z/bZ
# Paramètres: a, le nombre dont on veut connaître l'inverse; b, l'ensemble sur lequel chercher l'inverse
# Sortie: l'inverse de a (ex: )
def generer_inverse(a, b, x = 0, y = 1):
    x, y = y, x - (b // a) * y
    if b % a == 0:
        return x, y
    return generer_inverse(b % a, a, x, y)

# Objectif: cette fonction génère les clefs p, q, n, phi, e, et d pour RSA
# Paramètres: aucun
# Sortie: les clés p, q, n, phi, e, et d dans un dictionnaire
def generer_clefs_rsa():
    # Génère deux nombres premiers p et q
    p = generer_nombre_premier(pow(10, 3), pow(10, 6))
    q = generer_nombre_premier(pow(10, 3), pow(10, 6))
    n = p * q
    phi = (p - 1) * (q - 1)
    e = generer_e_rsa(phi)
    d = generer_inverse(e, phi)[0]
    # Si l'inverse de e (d) est d < 0 ou d > phi, le remettre dans l'intervalle [0, phi-1]
    d %= phi
    keys = {
        "p": p,
        "q": q,
        "phi": phi,
        "public": e,
        "private": d,
        "modulus": n
    }
    return keys

#TODO
# Objectif: cette fonction chiffre une lettre avec RSA
# Paramètres: lettre, la lettre à chiffrer; e et n, les clefs publiques
# Sortie: la lettre chiffré
def chiffrer_lettre_rsa(lettre, e, n):
    pass

#TODO
# Objectif: cette fonction déchiffre une lettre avec RSA
# Paramètres: lettre, la lettre à chiffrer; d et n, les clefs privées
# Sortie: la lettre chiffré
def dechiffrer_lettre_rsa(lettre, d, n):
    pass
