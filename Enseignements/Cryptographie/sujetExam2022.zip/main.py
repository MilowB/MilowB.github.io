'''
-------------------------------
# CONSIGNES
-------------------------------

/!\ Ne pas modifier /!\ 
/!\ Vous n'avez pas nécessairement besoin de comprendre ce script /!\ 

'''

from script import *
import random
import string

def generer_string(taille):
    letters = string.ascii_lowercase
    result_str = ''.join(random.choice(letters) for i in range(taille))
    return result_str

def estPremier(x):
    flag = False
    while not flag:
        for i in range(2, x):
            if (x % i) == 0:
                flag = True
                break
        return not flag

def chiffrer_message(message, e, n):
    c = []
    for i in range(len(message)):
        try:
            c.append(chiffrer_lettre_rsa(message[i], e, n))
        except:
            c.append(0)
    return "-".join([str(num) for num in c])

def dechiffrer_message(message, d, n):
    m = []
    mots = message.split("-")
    for lettre in mots:
        try:
            m.append(dechiffrer_lettre_rsa(lettre, d, n))
        except:
            m.append("")
    return "".join(m)

if __name__ == '__main__':
    d = {}
    note_totale = 0

    id = identifiants()
    d["prenom"] = id[0]
    d["nom"] = id[1]


    ################# evalutation de AES #################

    clef = generer_clef()
    chiffreur = generer_chiffreurf()
    dechiffreur = generer_dechiffreurf()

    note_aes = 0
    for i in range(10, 17):
        msgClair1 = generer_string(i)
        msgChiffre = chiffrer_message_aes(chiffreur, clef, msgClair1)
        try:
            msgClair2 = dechiffrer_message_aes(dechiffreur, clef, msgChiffre).decode('ascii')
            if msgClair1 == msgClair2:
                note_aes += 1
        except:
            pass
    
    note_totale += note_aes
    print("Note sur AES: ", note_aes, "/ 7")

    ################# evalutation de RSA #################

    note_pgcd = 0
    if pgcd(221, 782) == 17:
        note_pgcd += 2

    note_totale += note_pgcd
    print("Note sur PGCD: ", note_pgcd, "/ 2")

    cles = None
    try:
        cles = generer_clefs_rsa()
    except:
        cles = {
            "p": -1,
            "q": -1,
            "phi": -1,
            "public": -1,
            "private": -1,
            "modulus": -1
        }
    
    note_phi = 0
    if pgcd(cles["public"], cles["phi"]) == 1:
        note_phi += 2

    note_totale += note_phi
    print("Note sur génération de Phi: ", note_phi, "/ 2")

    note_premier = 0
    if cles["p"] != -1  and cles["q"] != -1 and estPremier(cles["p"]) and estPremier(cles["q"]):
        note_premier += 1

    note_totale += note_premier
    print("Note génération de premiers: ", note_premier, "/ 1")

    note_rsa = 0
    for i in range(1, 801):
        msgClair1 = generer_string(i)
        msgChiffre = ""
        msgClair2 = ""
        try:
            msgChiffre = chiffrer_message(msgClair1, cles["public"], cles["modulus"])
        except:
            msgChiffre = None
        try:
            msgClair2 = dechiffrer_message(msgChiffre, cles["private"], cles["modulus"])
        except:
            msgClair2 = None

        if msgChiffre != None and msgClair2 != None and msgClair1 == msgClair2:
            note_rsa += 0.01

    note_totale += round(note_rsa, 2)
    print("Note sur RSA: ", round(note_rsa, 2), "/ 8")
    print("\n---NOTE FINALE (SIMULATION)---")
    print(d["prenom"], d["nom"], " -> ", round(note_totale, 2), "/ 20")

    print("\n(Cette simulation est une version simplifiée du script de correction final et ne garantit pas la note indiquée)")